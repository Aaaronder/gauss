﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chizma
{
    public partial class Form1 : Form
    {
        double Gauss(double x)
        {
            int sigma2 = 1;
            int m = 0;

            return Math.Pow((1 / Math.Sqrt(sigma2) * Math.Sqrt(2 * Math.PI)) * Math.E, -1 * (Math.Pow(x - m, 2) / 2 * sigma2));
        }

        public Form1()
        {
            InitializeComponent();
        }

        List<double> alista = new List<double>();

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "";

            for (double i = -4; i <= 4; i += 0.5)
            {
                alista.Add(Gauss(i));
                label1.Text += Convert.ToString(Gauss(i) + "\n");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < alista.Count; i++)
            {
                ProgressBar csik = new System.Windows.Forms.ProgressBar();
                csik.Location = new Point(10, i * 25);
                csik.Height = 20;
                csik.Width = 400;
                csik.Show();
                csik.Minimum = 0;
                csik.Maximum = (int) Math.Ceiling(alista.Max()*100);
                csik.Value = (int)alista[i] * 100;
                Controls.Add(csik);
            }
        }
    }
}